
const Cars = require('../models/carModel');

const carController = {
  carsDetail: (req, res) => {
    Cars.getAllCars((err, carsData) => {
      if (err) {
        console.error('Error retrieving cars detail: ' + err.message);
        return res.status(500).json({ error: 'Failed to retrieve cars' });
      }
      console.log(carsData);
      res.render('carList', { carsData });

    });
  },

  deleteCar: (req, res) => {
    const carId = req.params.id;

    Cars.deleteCarById(carId, (err, result) => {
      if (err) {
        console.error('Error deleting car: ' + err.message);
        return res.status(500).json({ error: 'Failed to delete car' });
      }
      res.status(200).json({ message: 'Car deleted successfully' });
    });
  },
  addCar: (req, res) => {
    const carData = req.body;

    Cars.addCar(carData, (err, result) => {
      if (err) {
        console.error('Error adding car: ' + err.message);
        return res.status(500).json({ error: 'Failed to add car' });
      }
      res.status(201).json({ message: 'Car added successfully' });
    });
  }

  , searchCars: (req, res) => {
    const name = req.query.name;

    Cars.searchCarsByName(name, (err, carsData) => {
      if (err) {
        console.error('Error searching cars: ' + err.message);
        return res.status(500).json({ error: 'Failed to search cars' });
      }
      res.status(200).json(carsData);
    });
  }


  ,  requestRental: (req, res) => {
    const { carId, numberOfDays } = req.body;
    const userID = 1; // This should be retrieved from the authenticated user session

    Cars.updateCarStatus(carId, 'request_pending', (err) => {
      if (err) {
        console.error('Error updating car status: ' + err.message);
        return res.status(500).json({ error: 'Failed to update car status' });
      }

      const rentalRequest = { userID, carID: carId, numberOfDays };

      Cars.addRentalRequest(rentalRequest, (err, result) => {
        if (err) {
          console.error('Error adding rental request: ' + err.message);
          return res.status(500).json({ error: 'Failed to add rental request' });
        }
        res.json({ message: 'Rental request submitted successfully' });
      });
    });
  },


   listPendingRequests: (req, res) => {
    Cars.getPendingRequests((err, requests) => {
      if (err) {
        console.error('Error retrieving pending requests: ' + err.message);
        return res.status(500).json({ error: 'Failed to retrieve pending requests' });
      }
      res.render('pendingRequests', { requests });
    });
  },


  // approveRequest: (req, res) => {
  //   const { requestId, carId, approvedPrice, rentStartDate, rentDueDate } = req.body;
    
  //   Cars.approveRequest(requestId, carId, approvedPrice, rentStartDate, rentDueDate, (err) => {
  //     if (err) {
  //       console.error('Error approving request: ' + err.message);
  //       return res.status(500).json({ error: 'Failed to approve request' });
  //     }
  //     res.redirect('/pendingRequests');

  //     res.json({ message: 'Request approved successfully' });
  //   });
  // },

  approveRRequest: (req, res) => {
    const { requestId, carId, approvedPrice, rentStartDate, rentDueDate } = req.body;
    
    Cars.approveRequest(requestId, carId, approvedPrice, rentStartDate, rentDueDate, (err) => {
      if (err) {
        console.error('Error approving request: ' + err.message);
        return res.status(500).json({ error: 'Failed to approve request' });
      }
      res.redirect('/pendingRequests');
      // res.json({ message: 'Request approved successfully' });
    });
},


  rejectRRequest: (req, res) => {
    const { requestId, carId } = req.body;
    
    Cars.rejectRequest(requestId, carId, (err) => {
      if (err) {
        console.error('Error rejecting request: ' + err.message);
        return res.status(500).json({ error: 'Failed to reject request' });
      }
      res.redirect('/pendingRequests');

      // res.json({ message: 'Request rejected successfully' });
    });
  }
};

module.exports = carController;
