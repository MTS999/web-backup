
const db = require('../config/database');

const Cars = {
  getAllCars: (callback) => {
    const query = 'SELECT id, name, model, year, price, rentPerDay,status FROM Cars';
    console.log(query);
    db.query(query, callback);
  },

  deleteCarById: (carId, callback) => {
    const query = 'DELETE FROM Cars WHERE id = ?';
    db.query(query, [carId], callback);
  },
  addCar: (carData, callback) => {
    const query = 'INSERT INTO Cars (name, model, year, price, rentPerDay,status) VALUES (?, ?, ?, ?, ?,?)';
    db.query(query, [carData.name, carData.model, carData.year, carData.price, carData.rentPerDay,carData.status], callback);
  },


  searchCarsByName: (name, callback) => {
    const query = 'SELECT id, name, model, year, price, rentPerDay ,status FROM Cars WHERE name LIKE ?';
    db.query(query, [`%${name}%`], callback);
  },

  updateCarStatus: (carId, status, callback) => {
    const query = 'UPDATE Cars SET status = ? WHERE id = ?';
    db.query(query, [status, carId], callback);
  }, addRentalRequest: (request, callback) => {
    const query = 'INSERT INTO RentalRequest (userID, carID, requestDate, numberOfDays) VALUES (?, ?, NOW(), ?)';
    db.query(query, [request.userID, request.carID, request.numberOfDays], callback);
  },


  getPendingRequests: (callback) => {
    const query = `
      SELECT rr.id, rr.requestDate, rr.numberOfDays, c.name AS carName, c.model, c.year, u.fullname AS userName, u.email
      FROM RentalRequest rr
      JOIN Cars c ON rr.carID = c.id
      JOIN Customer u ON rr.userID = u.id
      WHERE c.status = 'request_pending'
    `;
    db.query(query, callback);
  },



  approveRequest: (requestId, carId, approvedPrice, rentStartDate, rentDueDate, callback) => {
    const query = `
      INSERT INTO ApprovedRequest (requestID, approvedPrice, rentStartDate, rentDueDate, status)
      VALUES (?, ?, ?, ?, 'ongoing');
      UPDATE Cars SET status = 'rented' WHERE id = ?;
    `;
    db.query(query, [requestId, approvedPrice, rentStartDate, rentDueDate, carId], callback);
  },

  rejectRequest: (requestId, carId, callback) => {
    const query = `
      DELETE FROM RentalRequest WHERE id = ?;
      UPDATE Cars SET status = 'available' WHERE id = ?;
    `;
    db.query(query, [requestId, carId], callback);
  }
};


module.exports = Cars;
